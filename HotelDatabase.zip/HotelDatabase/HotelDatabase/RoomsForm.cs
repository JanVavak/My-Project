﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelDatabase
{
    public partial class RoomsForm : Form
    {
        public RoomsForm()
        {
            InitializeComponent();
        }
        RoomClass room = new RoomClass();
        private void RoomsForm_Load(object sender, EventArgs e)
        {
            category_cm.DataSource = room.pokojeTypList();
            category_cm.DisplayMember = "label";
            category_cm.ValueMember = "id";

            dataGridView1.DataSource = room.pokojeList();
        }

        private void add_bt_Click(object sender, EventArgs e)
        {
            int type = Convert.ToInt32(category_cm.SelectedValue.ToString());
            string phone = phone_tb.Text;
            string free = "";

            try
            {
                int number = Convert.ToInt32(number_tb.Text);
                if (yes_rb.Checked)
                {
                    free = "Ano";
                }
                else if (no_rb.Checked)
                {
                    free = "Ne";
                }
                if (room.addRoom(number, type, phone, free))
                {
                    MessageBox.Show("Pokoj byl přidán", "Přidání pokoje", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dataGridView1.DataSource = room.pokojeList();
                }
                else
                {
                    MessageBox.Show("Pokoj nebyl přidán", "Přidání pokoje", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Chyba v čísle pokoje", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void edit_bt_Click(object sender, EventArgs e)
        {
            int number;
            int type = Convert.ToInt32(category_cm.SelectedValue.ToString());
            string phone = phone_tb.Text;
            string free = "";
            try
            {
                number = Convert.ToInt32(number_tb.Text);
                if (yes_rb.Checked)
                {
                    free = "Ano";
                }
                else if (no_rb.Checked)
                {
                    free = "Ne";
                }
                if (room.editRoom(number, type, phone, free))
                {
                    MessageBox.Show("Pokoj byl upraven", "Upravení pokoje", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dataGridView1.DataSource = room.pokojeList();
                }
                else
                {
                    MessageBox.Show("Pokoj nebyl upraven", "Upravení pokoje", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Chyba v čísle pokoje", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void remove_bt_Click(object sender, EventArgs e)
        {
            int number;
            try
            {
                number = Convert.ToInt32(number_tb.Text);
                if (room.removeRoom(number))
                {
                    MessageBox.Show("Pokoj byl odstraněn", "Odstranění pokoje", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dataGridView1.DataSource = room.pokojeList();
                    clear_bt.PerformClick();
                }
                else
                {
                    MessageBox.Show("Pokoj nebyl odstraněn", "Odstranění pokoje", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Chyba v čísle pokoje", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void clear_bt_Click(object sender, EventArgs e)
        {
            number_tb.Text = "";
            category_cm.SelectedIndex = 0;
            phone_tb.Text = "";
        }
        //Zobrazí hodnoty polí do textboxů
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            number_tb.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            category_cm.SelectedValue = dataGridView1.CurrentRow.Cells[1].Value;
            phone_tb.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();

            string free = dataGridView1.CurrentRow.Cells[3].Value.ToString();

            if (free.Equals("Ano"))
            {
                yes_rb.Checked = true;
            }
            else if (free.Equals("Ne"))
            {
                no_rb.Checked = true;
            }
        }
    }
}
