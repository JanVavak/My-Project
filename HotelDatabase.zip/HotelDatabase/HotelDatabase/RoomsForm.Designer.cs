﻿namespace HotelDatabase
{
    partial class RoomsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.no_rb = new System.Windows.Forms.RadioButton();
            this.yes_rb = new System.Windows.Forms.RadioButton();
            this.free_lb1 = new System.Windows.Forms.Label();
            this.category_cm = new System.Windows.Forms.ComboBox();
            this.clear_bt = new System.Windows.Forms.Button();
            this.remove_bt = new System.Windows.Forms.Button();
            this.edit_bt = new System.Windows.Forms.Button();
            this.add_bt = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.phone_tb = new System.Windows.Forms.TextBox();
            this.phone_lb = new System.Windows.Forms.Label();
            this.fname_lb = new System.Windows.Forms.Label();
            this.number_tb = new System.Windows.Forms.TextBox();
            this.id_lb = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rooms_lb = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.no_rb);
            this.panel1.Controls.Add(this.yes_rb);
            this.panel1.Controls.Add(this.free_lb1);
            this.panel1.Controls.Add(this.category_cm);
            this.panel1.Controls.Add(this.clear_bt);
            this.panel1.Controls.Add(this.remove_bt);
            this.panel1.Controls.Add(this.edit_bt);
            this.panel1.Controls.Add(this.add_bt);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.phone_tb);
            this.panel1.Controls.Add(this.phone_lb);
            this.panel1.Controls.Add(this.fname_lb);
            this.panel1.Controls.Add(this.number_tb);
            this.panel1.Controls.Add(this.id_lb);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1382, 833);
            this.panel1.TabIndex = 1;
            // 
            // no_rb
            // 
            this.no_rb.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.no_rb.Location = new System.Drawing.Point(372, 500);
            this.no_rb.Name = "no_rb";
            this.no_rb.Size = new System.Drawing.Size(169, 38);
            this.no_rb.TabIndex = 20;
            this.no_rb.TabStop = true;
            this.no_rb.Text = "Ne";
            this.no_rb.UseVisualStyleBackColor = true;
            // 
            // yes_rb
            // 
            this.yes_rb.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.yes_rb.Location = new System.Drawing.Point(197, 500);
            this.yes_rb.Name = "yes_rb";
            this.yes_rb.Size = new System.Drawing.Size(169, 38);
            this.yes_rb.TabIndex = 19;
            this.yes_rb.Text = "Ano";
            this.yes_rb.UseVisualStyleBackColor = true;
            // 
            // free_lb1
            // 
            this.free_lb1.BackColor = System.Drawing.SystemColors.Control;
            this.free_lb1.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.free_lb1.Location = new System.Drawing.Point(8, 500);
            this.free_lb1.Name = "free_lb1";
            this.free_lb1.Size = new System.Drawing.Size(181, 38);
            this.free_lb1.TabIndex = 17;
            this.free_lb1.Text = "Volno:";
            this.free_lb1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // category_cm
            // 
            this.category_cm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.category_cm.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.category_cm.FormattingEnabled = true;
            this.category_cm.Location = new System.Drawing.Point(197, 300);
            this.category_cm.Name = "category_cm";
            this.category_cm.Size = new System.Drawing.Size(350, 42);
            this.category_cm.TabIndex = 16;
            // 
            // clear_bt
            // 
            this.clear_bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.clear_bt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clear_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clear_bt.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.clear_bt.Location = new System.Drawing.Point(41, 725);
            this.clear_bt.Name = "clear_bt";
            this.clear_bt.Size = new System.Drawing.Size(500, 50);
            this.clear_bt.TabIndex = 15;
            this.clear_bt.Text = "Vyčistit pole s údaji";
            this.clear_bt.UseVisualStyleBackColor = false;
            this.clear_bt.Click += new System.EventHandler(this.clear_bt_Click);
            // 
            // remove_bt
            // 
            this.remove_bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.remove_bt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.remove_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.remove_bt.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.remove_bt.Location = new System.Drawing.Point(391, 660);
            this.remove_bt.Name = "remove_bt";
            this.remove_bt.Size = new System.Drawing.Size(150, 50);
            this.remove_bt.TabIndex = 14;
            this.remove_bt.Text = "Odebrat";
            this.remove_bt.UseVisualStyleBackColor = false;
            this.remove_bt.Click += new System.EventHandler(this.remove_bt_Click);
            // 
            // edit_bt
            // 
            this.edit_bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.edit_bt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.edit_bt.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.edit_bt.Location = new System.Drawing.Point(216, 660);
            this.edit_bt.Name = "edit_bt";
            this.edit_bt.Size = new System.Drawing.Size(150, 50);
            this.edit_bt.TabIndex = 13;
            this.edit_bt.Text = "Upravit";
            this.edit_bt.UseVisualStyleBackColor = false;
            this.edit_bt.Click += new System.EventHandler(this.edit_bt_Click);
            // 
            // add_bt
            // 
            this.add_bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.add_bt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.add_bt.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.add_bt.Location = new System.Drawing.Point(41, 660);
            this.add_bt.Name = "add_bt";
            this.add_bt.Size = new System.Drawing.Size(150, 50);
            this.add_bt.TabIndex = 12;
            this.add_bt.Text = "Přidat";
            this.add_bt.UseVisualStyleBackColor = false;
            this.add_bt.Click += new System.EventHandler(this.add_bt_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(600, 75);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(735, 749);
            this.dataGridView1.TabIndex = 11;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // phone_tb
            // 
            this.phone_tb.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.phone_tb.Location = new System.Drawing.Point(197, 400);
            this.phone_tb.Name = "phone_tb";
            this.phone_tb.Size = new System.Drawing.Size(350, 38);
            this.phone_tb.TabIndex = 8;
            // 
            // phone_lb
            // 
            this.phone_lb.BackColor = System.Drawing.SystemColors.Control;
            this.phone_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.phone_lb.Location = new System.Drawing.Point(8, 400);
            this.phone_lb.Name = "phone_lb";
            this.phone_lb.Size = new System.Drawing.Size(181, 38);
            this.phone_lb.TabIndex = 7;
            this.phone_lb.Text = "Telefon:";
            this.phone_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // fname_lb
            // 
            this.fname_lb.BackColor = System.Drawing.SystemColors.Control;
            this.fname_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.fname_lb.Location = new System.Drawing.Point(8, 300);
            this.fname_lb.Name = "fname_lb";
            this.fname_lb.Size = new System.Drawing.Size(183, 42);
            this.fname_lb.TabIndex = 3;
            this.fname_lb.Text = "Typ pokoje:";
            this.fname_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // number_tb
            // 
            this.number_tb.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.number_tb.Location = new System.Drawing.Point(197, 200);
            this.number_tb.Name = "number_tb";
            this.number_tb.Size = new System.Drawing.Size(350, 38);
            this.number_tb.TabIndex = 2;
            // 
            // id_lb
            // 
            this.id_lb.BackColor = System.Drawing.SystemColors.Control;
            this.id_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.id_lb.Location = new System.Drawing.Point(10, 200);
            this.id_lb.Name = "id_lb";
            this.id_lb.Size = new System.Drawing.Size(181, 38);
            this.id_lb.TabIndex = 1;
            this.id_lb.Text = "Číslo";
            this.id_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.rooms_lb);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1418, 65);
            this.panel2.TabIndex = 0;
            // 
            // rooms_lb
            // 
            this.rooms_lb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rooms_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rooms_lb.Location = new System.Drawing.Point(0, 0);
            this.rooms_lb.Name = "rooms_lb";
            this.rooms_lb.Size = new System.Drawing.Size(1418, 65);
            this.rooms_lb.TabIndex = 0;
            this.rooms_lb.Text = "Pokoje";
            this.rooms_lb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RoomsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1382, 833);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RoomsForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.RoomsForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button clear_bt;
        private System.Windows.Forms.Button remove_bt;
        private System.Windows.Forms.Button edit_bt;
        private System.Windows.Forms.Button add_bt;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox phone_tb;
        private System.Windows.Forms.Label phone_lb;
        private System.Windows.Forms.Label fname_lb;
        private System.Windows.Forms.TextBox number_tb;
        private System.Windows.Forms.Label id_lb;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label rooms_lb;
        private System.Windows.Forms.ComboBox category_cm;
        private System.Windows.Forms.Label free_lb1;
        private System.Windows.Forms.RadioButton no_rb;
        private System.Windows.Forms.RadioButton yes_rb;
    }
}