﻿namespace HotelDatabase
{
    partial class ReservationsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.res_tb = new System.Windows.Forms.TextBox();
            this.ress_lb = new System.Windows.Forms.Label();
            this.end_lb = new System.Windows.Forms.Label();
            this.end_dtp = new System.Windows.Forms.DateTimePicker();
            this.start_lb = new System.Windows.Forms.Label();
            this.start_dtp = new System.Windows.Forms.DateTimePicker();
            this.category_cm = new System.Windows.Forms.ComboBox();
            this.category_lb = new System.Windows.Forms.Label();
            this.id_lb = new System.Windows.Forms.Label();
            this.number_cm = new System.Windows.Forms.ComboBox();
            this.clear_bt = new System.Windows.Forms.Button();
            this.remove_bt = new System.Windows.Forms.Button();
            this.edit_bt = new System.Windows.Forms.Button();
            this.add_bt = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.number_lb = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.res_lb = new System.Windows.Forms.Label();
            this.id_tb = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.id_tb);
            this.panel1.Controls.Add(this.res_tb);
            this.panel1.Controls.Add(this.ress_lb);
            this.panel1.Controls.Add(this.end_lb);
            this.panel1.Controls.Add(this.end_dtp);
            this.panel1.Controls.Add(this.start_lb);
            this.panel1.Controls.Add(this.start_dtp);
            this.panel1.Controls.Add(this.category_cm);
            this.panel1.Controls.Add(this.category_lb);
            this.panel1.Controls.Add(this.id_lb);
            this.panel1.Controls.Add(this.number_cm);
            this.panel1.Controls.Add(this.clear_bt);
            this.panel1.Controls.Add(this.remove_bt);
            this.panel1.Controls.Add(this.edit_bt);
            this.panel1.Controls.Add(this.add_bt);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.number_lb);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1382, 833);
            this.panel1.TabIndex = 2;
            // 
            // res_tb
            // 
            this.res_tb.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.res_tb.Location = new System.Drawing.Point(197, 120);
            this.res_tb.Name = "res_tb";
            this.res_tb.Size = new System.Drawing.Size(350, 38);
            this.res_tb.TabIndex = 26;
            // 
            // ress_lb
            // 
            this.ress_lb.BackColor = System.Drawing.SystemColors.Control;
            this.ress_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ress_lb.Location = new System.Drawing.Point(10, 120);
            this.ress_lb.Name = "ress_lb";
            this.ress_lb.Size = new System.Drawing.Size(181, 38);
            this.ress_lb.TabIndex = 25;
            this.ress_lb.Text = "ID Rezervace:";
            this.ress_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // end_lb
            // 
            this.end_lb.BackColor = System.Drawing.SystemColors.Control;
            this.end_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.end_lb.Location = new System.Drawing.Point(10, 545);
            this.end_lb.Name = "end_lb";
            this.end_lb.Size = new System.Drawing.Size(183, 42);
            this.end_lb.TabIndex = 24;
            this.end_lb.Text = "Konec:";
            this.end_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // end_dtp
            // 
            this.end_dtp.CalendarFont = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.end_dtp.CustomFormat = "dd/MM/yyyy";
            this.end_dtp.Font = new System.Drawing.Font("Franklin Gothic Medium", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.end_dtp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.end_dtp.Location = new System.Drawing.Point(197, 545);
            this.end_dtp.Name = "end_dtp";
            this.end_dtp.Size = new System.Drawing.Size(350, 42);
            this.end_dtp.TabIndex = 23;
            // 
            // start_lb
            // 
            this.start_lb.BackColor = System.Drawing.SystemColors.Control;
            this.start_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.start_lb.Location = new System.Drawing.Point(10, 460);
            this.start_lb.Name = "start_lb";
            this.start_lb.Size = new System.Drawing.Size(183, 42);
            this.start_lb.TabIndex = 22;
            this.start_lb.Text = "Začátek:";
            this.start_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // start_dtp
            // 
            this.start_dtp.CalendarFont = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.start_dtp.CustomFormat = "dd/MM/yyyy";
            this.start_dtp.Font = new System.Drawing.Font("Franklin Gothic Medium", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.start_dtp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.start_dtp.Location = new System.Drawing.Point(197, 460);
            this.start_dtp.Name = "start_dtp";
            this.start_dtp.Size = new System.Drawing.Size(350, 42);
            this.start_dtp.TabIndex = 21;
            // 
            // category_cm
            // 
            this.category_cm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.category_cm.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.category_cm.FormattingEnabled = true;
            this.category_cm.Location = new System.Drawing.Point(197, 290);
            this.category_cm.Name = "category_cm";
            this.category_cm.Size = new System.Drawing.Size(350, 42);
            this.category_cm.TabIndex = 20;
            this.category_cm.SelectedIndexChanged += new System.EventHandler(this.category_cm_SelectedIndexChanged);
            // 
            // category_lb
            // 
            this.category_lb.BackColor = System.Drawing.SystemColors.Control;
            this.category_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.category_lb.Location = new System.Drawing.Point(10, 290);
            this.category_lb.Name = "category_lb";
            this.category_lb.Size = new System.Drawing.Size(183, 42);
            this.category_lb.TabIndex = 19;
            this.category_lb.Text = "Typ pokoje:";
            this.category_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // id_lb
            // 
            this.id_lb.BackColor = System.Drawing.SystemColors.Control;
            this.id_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.id_lb.Location = new System.Drawing.Point(10, 205);
            this.id_lb.Name = "id_lb";
            this.id_lb.Size = new System.Drawing.Size(181, 38);
            this.id_lb.TabIndex = 17;
            this.id_lb.Text = "ID Klienta:";
            this.id_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // number_cm
            // 
            this.number_cm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.number_cm.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.number_cm.FormattingEnabled = true;
            this.number_cm.Location = new System.Drawing.Point(195, 375);
            this.number_cm.Name = "number_cm";
            this.number_cm.Size = new System.Drawing.Size(350, 42);
            this.number_cm.TabIndex = 16;
            // 
            // clear_bt
            // 
            this.clear_bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.clear_bt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clear_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clear_bt.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.clear_bt.Location = new System.Drawing.Point(41, 725);
            this.clear_bt.Name = "clear_bt";
            this.clear_bt.Size = new System.Drawing.Size(500, 50);
            this.clear_bt.TabIndex = 15;
            this.clear_bt.Text = "Vyčistit pole s údaji";
            this.clear_bt.UseVisualStyleBackColor = false;
            this.clear_bt.Click += new System.EventHandler(this.clear_bt_Click);
            // 
            // remove_bt
            // 
            this.remove_bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.remove_bt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.remove_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.remove_bt.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.remove_bt.Location = new System.Drawing.Point(391, 660);
            this.remove_bt.Name = "remove_bt";
            this.remove_bt.Size = new System.Drawing.Size(150, 50);
            this.remove_bt.TabIndex = 14;
            this.remove_bt.Text = "Odebrat";
            this.remove_bt.UseVisualStyleBackColor = false;
            this.remove_bt.Click += new System.EventHandler(this.remove_bt_Click);
            // 
            // edit_bt
            // 
            this.edit_bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.edit_bt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.edit_bt.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.edit_bt.Location = new System.Drawing.Point(216, 660);
            this.edit_bt.Name = "edit_bt";
            this.edit_bt.Size = new System.Drawing.Size(150, 50);
            this.edit_bt.TabIndex = 13;
            this.edit_bt.Text = "Upravit";
            this.edit_bt.UseVisualStyleBackColor = false;
            this.edit_bt.Click += new System.EventHandler(this.edit_bt_Click);
            // 
            // add_bt
            // 
            this.add_bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.add_bt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.add_bt.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.add_bt.Location = new System.Drawing.Point(41, 660);
            this.add_bt.Name = "add_bt";
            this.add_bt.Size = new System.Drawing.Size(150, 50);
            this.add_bt.TabIndex = 12;
            this.add_bt.Text = "Přidat";
            this.add_bt.UseVisualStyleBackColor = false;
            this.add_bt.Click += new System.EventHandler(this.add_bt_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(600, 75);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(735, 749);
            this.dataGridView1.TabIndex = 11;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // number_lb
            // 
            this.number_lb.BackColor = System.Drawing.SystemColors.Control;
            this.number_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.number_lb.Location = new System.Drawing.Point(8, 375);
            this.number_lb.Name = "number_lb";
            this.number_lb.Size = new System.Drawing.Size(183, 42);
            this.number_lb.TabIndex = 3;
            this.number_lb.Text = "Číslo Pokoje:";
            this.number_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.res_lb);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1418, 65);
            this.panel2.TabIndex = 0;
            // 
            // res_lb
            // 
            this.res_lb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.res_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.res_lb.Location = new System.Drawing.Point(0, 0);
            this.res_lb.Name = "res_lb";
            this.res_lb.Size = new System.Drawing.Size(1418, 65);
            this.res_lb.TabIndex = 0;
            this.res_lb.Text = "Rezervace";
            this.res_lb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // id_tb
            // 
            this.id_tb.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.id_tb.Location = new System.Drawing.Point(197, 205);
            this.id_tb.Name = "id_tb";
            this.id_tb.Size = new System.Drawing.Size(350, 38);
            this.id_tb.TabIndex = 27;
            // 
            // ReservationsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1382, 833);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ReservationsForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.ReservationsForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox number_cm;
        private System.Windows.Forms.Button clear_bt;
        private System.Windows.Forms.Button remove_bt;
        private System.Windows.Forms.Button edit_bt;
        private System.Windows.Forms.Button add_bt;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label number_lb;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label res_lb;
        private System.Windows.Forms.Label id_lb;
        private System.Windows.Forms.ComboBox category_cm;
        private System.Windows.Forms.Label category_lb;
        private System.Windows.Forms.Label end_lb;
        private System.Windows.Forms.DateTimePicker end_dtp;
        private System.Windows.Forms.Label start_lb;
        private System.Windows.Forms.DateTimePicker start_dtp;
        private System.Windows.Forms.TextBox res_tb;
        private System.Windows.Forms.Label ress_lb;
        private System.Windows.Forms.TextBox id_tb;
    }
}