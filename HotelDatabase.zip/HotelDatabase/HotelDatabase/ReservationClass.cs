﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;

namespace HotelDatabase
{
    //Třída pro správu rezervací
    class ReservationClass
    {
        Connect conn = new Connect();
        //Funkce pro vytvoření listu rezervací
        public DataTable getReservations()
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM `rezervace`", conn.getConnection());
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();

            adapter.SelectCommand = command;
            adapter.Fill(table);

            return table;
        }
        //Funkce pro přidání rezervace
        public bool addRes(int resId,int roomNm, int clientId, DateTime dateIn, DateTime dateOut)
        {
            MySqlCommand command = new MySqlCommand();
            String insertQuery = "INSERT INTO `rezervace`(`resId`, `roomNm`, `clientId`, `dateIn`, `dateOut`) VALUES (@rid,@rnm,@cid,@din,@dout)";
            command.CommandText = insertQuery;
            command.Connection = conn.getConnection();

            command.Parameters.Add("@rid", MySqlDbType.Int32).Value = resId;
            command.Parameters.Add("@rnm", MySqlDbType.Int32).Value = roomNm;
            command.Parameters.Add("@cid", MySqlDbType.Int32).Value = clientId;
            command.Parameters.Add("@din", MySqlDbType.Date).Value = dateIn;
            command.Parameters.Add("@dout", MySqlDbType.Date).Value = dateOut;

            conn.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                conn.closeConnection();
                return true;
            }
            else
            {
                conn.closeConnection();
                return false;
            }
        }
        //Funkce pro úpravu rezervací
        public bool editRes(int resId, int roomNm, int clientId, DateTime dateIn, DateTime dateOut)
        {
            MySqlCommand command = new MySqlCommand();
            String insertQuery = "UPDATE `rezervace` SET `roomNm`=@rnm,`clientId`=@cid,`dateIn`=@din,`dateOut`=@dout WHERE `resId`=@rid";
            command.CommandText = insertQuery;
            command.Connection = conn.getConnection();

            command.Parameters.Add("@rid", MySqlDbType.Int32).Value = resId;
            command.Parameters.Add("@rnm", MySqlDbType.Int32).Value = roomNm;
            command.Parameters.Add("@cid", MySqlDbType.Int32).Value = clientId;
            command.Parameters.Add("@din", MySqlDbType.Date).Value = dateIn;
            command.Parameters.Add("@dout", MySqlDbType.Date).Value = dateOut;

            conn.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                conn.closeConnection();
                return true;
            }
            else
            {
                conn.closeConnection();
                return false;
            }
        }
        //Funkce pro ostranění rezervace
        public bool removeRes(int resId)
        {
            MySqlCommand command = new MySqlCommand();
            String insertQuery = "DELETE FROM `rezervace` WHERE `resId`=@rid";
            command.CommandText = insertQuery;
            command.Connection = conn.getConnection();

            command.Parameters.Add("@rid", MySqlDbType.Int32).Value = resId;

            conn.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                conn.closeConnection();
                return true;
            }
            else
            {
                conn.closeConnection();
                return false;
            }
        }
    }
}
