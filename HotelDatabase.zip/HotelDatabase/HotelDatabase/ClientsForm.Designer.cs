﻿namespace HotelDatabase
{
    partial class ClientsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.clear_bt = new System.Windows.Forms.Button();
            this.remove_bt = new System.Windows.Forms.Button();
            this.edit_bt = new System.Windows.Forms.Button();
            this.add_bt = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.country_tb = new System.Windows.Forms.TextBox();
            this.country_lb = new System.Windows.Forms.Label();
            this.phone_tb = new System.Windows.Forms.TextBox();
            this.phone_lb = new System.Windows.Forms.Label();
            this.lname_tb = new System.Windows.Forms.TextBox();
            this.lname_lb = new System.Windows.Forms.Label();
            this.fname_tb = new System.Windows.Forms.TextBox();
            this.fname_lb = new System.Windows.Forms.Label();
            this.id_tb = new System.Windows.Forms.TextBox();
            this.id_lb = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.clients_lb = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.clear_bt);
            this.panel1.Controls.Add(this.remove_bt);
            this.panel1.Controls.Add(this.edit_bt);
            this.panel1.Controls.Add(this.add_bt);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.country_tb);
            this.panel1.Controls.Add(this.country_lb);
            this.panel1.Controls.Add(this.phone_tb);
            this.panel1.Controls.Add(this.phone_lb);
            this.panel1.Controls.Add(this.lname_tb);
            this.panel1.Controls.Add(this.lname_lb);
            this.panel1.Controls.Add(this.fname_tb);
            this.panel1.Controls.Add(this.fname_lb);
            this.panel1.Controls.Add(this.id_tb);
            this.panel1.Controls.Add(this.id_lb);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1382, 833);
            this.panel1.TabIndex = 0;
            // 
            // clear_bt
            // 
            this.clear_bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.clear_bt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clear_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.clear_bt.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.clear_bt.Location = new System.Drawing.Point(41, 725);
            this.clear_bt.Name = "clear_bt";
            this.clear_bt.Size = new System.Drawing.Size(500, 50);
            this.clear_bt.TabIndex = 15;
            this.clear_bt.Text = "Vyčistit pole s údaji";
            this.clear_bt.UseVisualStyleBackColor = false;
            this.clear_bt.Click += new System.EventHandler(this.clear_bt_Click);
            // 
            // remove_bt
            // 
            this.remove_bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.remove_bt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.remove_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.remove_bt.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.remove_bt.Location = new System.Drawing.Point(391, 660);
            this.remove_bt.Name = "remove_bt";
            this.remove_bt.Size = new System.Drawing.Size(150, 50);
            this.remove_bt.TabIndex = 14;
            this.remove_bt.Text = "Odebrat";
            this.remove_bt.UseVisualStyleBackColor = false;
            this.remove_bt.Click += new System.EventHandler(this.remove_bt_Click);
            // 
            // edit_bt
            // 
            this.edit_bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.edit_bt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.edit_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.edit_bt.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.edit_bt.Location = new System.Drawing.Point(216, 660);
            this.edit_bt.Name = "edit_bt";
            this.edit_bt.Size = new System.Drawing.Size(150, 50);
            this.edit_bt.TabIndex = 13;
            this.edit_bt.Text = "Upravit";
            this.edit_bt.UseVisualStyleBackColor = false;
            this.edit_bt.Click += new System.EventHandler(this.edit_bt_Click);
            // 
            // add_bt
            // 
            this.add_bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.add_bt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.add_bt.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.add_bt.Location = new System.Drawing.Point(41, 660);
            this.add_bt.Name = "add_bt";
            this.add_bt.Size = new System.Drawing.Size(150, 50);
            this.add_bt.TabIndex = 12;
            this.add_bt.Text = "Přidat";
            this.add_bt.UseVisualStyleBackColor = false;
            this.add_bt.Click += new System.EventHandler(this.add_bt_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(600, 75);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(735, 749);
            this.dataGridView1.TabIndex = 11;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // country_tb
            // 
            this.country_tb.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.country_tb.Location = new System.Drawing.Point(197, 546);
            this.country_tb.Name = "country_tb";
            this.country_tb.Size = new System.Drawing.Size(350, 38);
            this.country_tb.TabIndex = 10;
            // 
            // country_lb
            // 
            this.country_lb.BackColor = System.Drawing.SystemColors.Control;
            this.country_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.country_lb.Location = new System.Drawing.Point(10, 546);
            this.country_lb.Name = "country_lb";
            this.country_lb.Size = new System.Drawing.Size(181, 38);
            this.country_lb.TabIndex = 9;
            this.country_lb.Text = "Země:";
            this.country_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // phone_tb
            // 
            this.phone_tb.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.phone_tb.Location = new System.Drawing.Point(197, 446);
            this.phone_tb.Name = "phone_tb";
            this.phone_tb.Size = new System.Drawing.Size(350, 38);
            this.phone_tb.TabIndex = 8;
            // 
            // phone_lb
            // 
            this.phone_lb.BackColor = System.Drawing.SystemColors.Control;
            this.phone_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.phone_lb.Location = new System.Drawing.Point(10, 446);
            this.phone_lb.Name = "phone_lb";
            this.phone_lb.Size = new System.Drawing.Size(181, 38);
            this.phone_lb.TabIndex = 7;
            this.phone_lb.Text = "Telefon:";
            this.phone_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lname_tb
            // 
            this.lname_tb.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lname_tb.Location = new System.Drawing.Point(197, 346);
            this.lname_tb.Name = "lname_tb";
            this.lname_tb.Size = new System.Drawing.Size(350, 38);
            this.lname_tb.TabIndex = 6;
            // 
            // lname_lb
            // 
            this.lname_lb.BackColor = System.Drawing.SystemColors.Control;
            this.lname_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lname_lb.Location = new System.Drawing.Point(10, 346);
            this.lname_lb.Name = "lname_lb";
            this.lname_lb.Size = new System.Drawing.Size(181, 38);
            this.lname_lb.TabIndex = 5;
            this.lname_lb.Text = "Příjmení:";
            this.lname_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // fname_tb
            // 
            this.fname_tb.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.fname_tb.Location = new System.Drawing.Point(197, 246);
            this.fname_tb.Name = "fname_tb";
            this.fname_tb.Size = new System.Drawing.Size(350, 38);
            this.fname_tb.TabIndex = 4;
            // 
            // fname_lb
            // 
            this.fname_lb.BackColor = System.Drawing.SystemColors.Control;
            this.fname_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.fname_lb.Location = new System.Drawing.Point(8, 246);
            this.fname_lb.Name = "fname_lb";
            this.fname_lb.Size = new System.Drawing.Size(183, 38);
            this.fname_lb.TabIndex = 3;
            this.fname_lb.Text = "Křestní Jméno:";
            this.fname_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // id_tb
            // 
            this.id_tb.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.id_tb.Location = new System.Drawing.Point(197, 146);
            this.id_tb.Name = "id_tb";
            this.id_tb.Size = new System.Drawing.Size(350, 38);
            this.id_tb.TabIndex = 2;
            // 
            // id_lb
            // 
            this.id_lb.BackColor = System.Drawing.SystemColors.Control;
            this.id_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.id_lb.Location = new System.Drawing.Point(10, 146);
            this.id_lb.Name = "id_lb";
            this.id_lb.Size = new System.Drawing.Size(181, 38);
            this.id_lb.TabIndex = 1;
            this.id_lb.Text = "ID:";
            this.id_lb.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel2.Controls.Add(this.clients_lb);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1418, 65);
            this.panel2.TabIndex = 0;
            // 
            // clients_lb
            // 
            this.clients_lb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.clients_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.clients_lb.Location = new System.Drawing.Point(0, 0);
            this.clients_lb.Name = "clients_lb";
            this.clients_lb.Size = new System.Drawing.Size(1418, 65);
            this.clients_lb.TabIndex = 0;
            this.clients_lb.Text = "Klienti";
            this.clients_lb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ClientsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1382, 833);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ClientsForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.ClientsForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label clients_lb;
        private System.Windows.Forms.TextBox id_tb;
        private System.Windows.Forms.Label id_lb;
        private System.Windows.Forms.TextBox country_tb;
        private System.Windows.Forms.Label country_lb;
        private System.Windows.Forms.TextBox phone_tb;
        private System.Windows.Forms.Label phone_lb;
        private System.Windows.Forms.TextBox lname_tb;
        private System.Windows.Forms.Label lname_lb;
        private System.Windows.Forms.TextBox fname_tb;
        private System.Windows.Forms.Label fname_lb;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button clear_bt;
        private System.Windows.Forms.Button remove_bt;
        private System.Windows.Forms.Button edit_bt;
        private System.Windows.Forms.Button add_bt;
    }
}