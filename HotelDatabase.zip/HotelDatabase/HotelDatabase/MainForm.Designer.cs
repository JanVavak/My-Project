﻿namespace HotelDatabase
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menu_ms = new System.Windows.Forms.MenuStrip();
            this.klientiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pokojeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rezervaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu_ms.SuspendLayout();
            this.SuspendLayout();
            // 
            // menu_ms
            // 
            this.menu_ms.BackColor = System.Drawing.SystemColors.ControlLight;
            this.menu_ms.Font = new System.Drawing.Font("Franklin Gothic Medium", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.menu_ms.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menu_ms.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.klientiToolStripMenuItem,
            this.pokojeToolStripMenuItem,
            this.rezervaceToolStripMenuItem});
            this.menu_ms.Location = new System.Drawing.Point(0, 0);
            this.menu_ms.Name = "menu_ms";
            this.menu_ms.Padding = new System.Windows.Forms.Padding(8, 3, 0, 3);
            this.menu_ms.Size = new System.Drawing.Size(800, 31);
            this.menu_ms.TabIndex = 1;
            // 
            // klientiToolStripMenuItem
            // 
            this.klientiToolStripMenuItem.Font = new System.Drawing.Font("Franklin Gothic Medium", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.klientiToolStripMenuItem.Name = "klientiToolStripMenuItem";
            this.klientiToolStripMenuItem.Size = new System.Drawing.Size(69, 25);
            this.klientiToolStripMenuItem.Text = "Klienti";
            this.klientiToolStripMenuItem.Click += new System.EventHandler(this.klientiToolStripMenuItem_Click);
            // 
            // pokojeToolStripMenuItem
            // 
            this.pokojeToolStripMenuItem.Font = new System.Drawing.Font("Franklin Gothic Medium", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pokojeToolStripMenuItem.Name = "pokojeToolStripMenuItem";
            this.pokojeToolStripMenuItem.Size = new System.Drawing.Size(74, 25);
            this.pokojeToolStripMenuItem.Text = "Pokoje";
            this.pokojeToolStripMenuItem.Click += new System.EventHandler(this.pokojeToolStripMenuItem_Click);
            // 
            // rezervaceToolStripMenuItem
            // 
            this.rezervaceToolStripMenuItem.Font = new System.Drawing.Font("Franklin Gothic Medium", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.rezervaceToolStripMenuItem.Name = "rezervaceToolStripMenuItem";
            this.rezervaceToolStripMenuItem.Size = new System.Drawing.Size(100, 25);
            this.rezervaceToolStripMenuItem.Text = "Rezervace";
            this.rezervaceToolStripMenuItem.Click += new System.EventHandler(this.rezervaceToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menu_ms);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menu_ms;
            this.Name = "MainForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.menu_ms.ResumeLayout(false);
            this.menu_ms.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menu_ms;
        private System.Windows.Forms.ToolStripMenuItem klientiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pokojeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rezervaceToolStripMenuItem;
    }
}