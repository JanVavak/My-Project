﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelDatabase
{
    public partial class ReservationsForm : Form
    {
        public ReservationsForm()
        {
            InitializeComponent();
        }

        RoomClass room = new RoomClass();
        ReservationClass reservation = new ReservationClass();

        private void ReservationsForm_Load(object sender, EventArgs e)
        {
            //Zobrazí druhy pokojů
            category_cm.DataSource = room.pokojeTypList();
            category_cm.DisplayMember = "label";
            category_cm.ValueMember = "id";

            //Zobrazí čísla pokojů
            int type = Convert.ToInt32(category_cm.SelectedValue.ToString());
            number_cm.DataSource = room.pokojePodleTypuList(type);
            number_cm.DisplayMember = "number";
            number_cm.ValueMember = "number";

            dataGridView1.DataSource = reservation.getReservations();
        }
        private void clear_bt_Click(object sender, EventArgs e)
        {
            res_tb.Text = "";
            id_tb.Text = "";
            category_cm.SelectedIndex = 0;
            start_dtp.Value = DateTime.Now;  
            end_dtp.Value = DateTime.Now;
        }

        private void category_cm_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int type = Convert.ToInt32(category_cm.SelectedValue.ToString());
                number_cm.DataSource = room.pokojePodleTypuList(type);
                number_cm.DisplayMember = "number";
                number_cm.ValueMember = "number";
            }
            catch (Exception)
            {
            }
        }

        private void add_bt_Click(object sender, EventArgs e)
        {
            try
            {
                int resId = Convert.ToInt32(res_tb.Text);
                int clientID = Convert.ToInt32(id_tb.Text);
                int roomNumber = Convert.ToInt32(number_cm.Text);
                DateTime dateIn = start_dtp.Value;
                DateTime dateOut = end_dtp.Value;

                if (dateIn.Date < DateTime.Now.Date)
                {
                    MessageBox.Show("Datum příjezdu musí být stejné či pozdější než je dnes", "Neplatné datum", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (dateOut.Date < dateIn.Date)
                {
                    MessageBox.Show("Datum odjezdu musí být stejné či pozdější než je datum příjezdu", "Neplatné datum", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (reservation.addRes(resId,roomNumber, clientID, dateIn, dateOut))
                    {
                        room.pokojeZmena(roomNumber, "Ne");
                        MessageBox.Show("Rezervace byla přidána", "Přidání rezervace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dataGridView1.DataSource = reservation.getReservations();
                    }
                    else
                    {
                        MessageBox.Show("Rezervace nebyla přidána", "Přidání rezervace", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Chyba v id rezervace", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void edit_bt_Click(object sender, EventArgs e)
        {
            try
            {
                int resID = Convert.ToInt32(res_tb.Text);
                int clientID = Convert.ToInt32(id_tb.Text);
                int roomNumber = Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                DateTime dateIn = start_dtp.Value;
                DateTime dateOut = end_dtp.Value;

                if (dateIn >= DateTime.Now)
                {
                    MessageBox.Show("Datum příjezdu musí být stejné či pozdější než je dnes", "Neplatné datum", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (dateOut <= dateIn)
                {
                    MessageBox.Show("Datum odjezdu musí být stejné či pozdější než je datum příjezdu", "Neplatné datum", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (reservation.editRes(resID, roomNumber, clientID, dateIn, dateOut))
                    {
                        room.pokojeZmena(roomNumber, "Ne");
                        MessageBox.Show("Rezervace byla upravena", "Úprava rezervace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dataGridView1.DataSource = reservation.getReservations();
                    }
                    else
                    {
                        MessageBox.Show("Rezervace nebyla upravena", "Úprava rezervace", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Chyba v id rezervace", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            res_tb.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();

            int roomId = Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value.ToString());

            category_cm.SelectedValue = room.pokojTyp(roomId);

            number_cm.SelectedValue = roomId;

            id_tb.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();

            start_dtp.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[3].Value);
            end_dtp.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells[4].Value);

        }

        private void remove_bt_Click(object sender, EventArgs e)
        {
            try
            {
                int resId = Convert.ToInt32(res_tb.Text);
                int roomNumber = Convert.ToInt32(dataGridView1.CurrentRow.Cells[1].Value.ToString());
                if (reservation.removeRes(resId))
                {
                    room.pokojeZmena(roomNumber, "Ano");
                    MessageBox.Show("Rezervace byla odstraněna", "Odstranění rezervace", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dataGridView1.DataSource = reservation.getReservations();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Chyba v id rezervace", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ALTER TABLE pokoje add CONSTRAINT fk_type_id FOREIGN KEY (type) REFERENCES pokoje_druhy(id) on UPDATE CASCADE on DELETE CASCADE;
        // ALTER TABLE rezervace add CONSTRAINT fk_room_number FOREIGN KEY (roomNm) REFERENCES pokoje(number) on UPDATE CASCADE on DELETE CASCADE;
        // ALTER TABLE rezervace add CONSTRAINT fk_client_id FOREIGN KEY (clientId) REFERENCES zázákazníci(id) on UPDATE CASCADE on DELETE CASCADE;
    }
}
