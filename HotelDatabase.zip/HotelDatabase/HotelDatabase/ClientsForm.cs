﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelDatabase
{
    public partial class ClientsForm : Form
    {
        ClientClass clt = new ClientClass();
        public ClientsForm()
        {
            InitializeComponent();
        }

        private void clear_bt_Click(object sender, EventArgs e)
        {
            id_tb.Text = "";
            fname_tb.Text = "";
            lname_tb.Text = "";
            phone_tb.Text = "";
            country_tb.Text = "";
        }

        private void add_bt_Click(object sender, EventArgs e)
        {
            int id;
            String fname = fname_tb.Text;
            String lname = lname_tb.Text;
            String phone = phone_tb.Text;
            String country = country_tb.Text;

            try
            {
                id = Convert.ToInt32(id_tb.Text);
                if (fname.Trim().Equals("") || lname.Trim().Equals("") || phone.Trim().Equals(""))
                {
                    MessageBox.Show("Chybí údaje", "Prázdná pole", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    Boolean addClient = clt.addClient(id, fname, lname, phone, country);

                    if (addClient)
                    {
                        MessageBox.Show("Klient byl přidán", "Přidání klienta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dataGridView1.DataSource = clt.getClients();
                    }
                    else
                    {
                        MessageBox.Show("Klient nebyl přidán", "Přidání klienta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Chyba v ID klienta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ClientsForm_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = clt.getClients();
        }

        private void edit_bt_Click(object sender, EventArgs e)
        {
            int id;
            String fname = fname_tb.Text;
            String lname = lname_tb.Text;
            String phone = phone_tb.Text;
            String country = country_tb.Text;

            try
            {
                id = Convert.ToInt32(id_tb.Text);

                if (fname.Trim().Equals("") || lname.Trim().Equals("") || phone.Trim().Equals(""))
                {
                    MessageBox.Show("Chybí údaje", "Prázdná pole", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    Boolean editClient = clt.editClient(id, fname, lname, phone, country);

                    if (editClient)
                    {
                        MessageBox.Show("Klient byl upraven", "Úprava klienta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dataGridView1.DataSource = clt.getClients();
                    }
                    else
                    {
                        MessageBox.Show("Klient nebyl upraven", "Úprava klienta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Chyba v ID klienta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Zobrazí hodnoty polí do textboxů
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id_tb.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            fname_tb.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            lname_tb.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            phone_tb.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            country_tb.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
        }

        private void remove_bt_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(id_tb.Text);

                if (clt.removeClient(id))
                {
                    MessageBox.Show("Klient byl odstraněn", "Odstranění klienta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dataGridView1.DataSource = clt.getClients();
                    clear_bt.PerformClick();
                }
                else
                {
                    MessageBox.Show("Klient nebyl odstraněn", "Odstranění klienta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Chyba v ID klienta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
