﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace HotelDatabase
{
    //Tato třída zajistí spojení mezi aplikací a mysql databází
    class Connect
    {
        private MySqlConnection connection = new MySqlConnection("datasource=localhost;port=3308;username=root;password=;database=HotelSystem;");

        //Funkce vracející spojení
        public MySqlConnection getConnection()
        {
            return connection;
        }

        //Funkce navazující spojení
        public void openConnection()
        {
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        //Funkce ukončující spojení
        public void closeConnection()
        {
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }
    }
}
