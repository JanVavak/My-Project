﻿namespace HotelDatabase
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.login_lb = new System.Windows.Forms.Label();
            this.login_gb = new System.Windows.Forms.GroupBox();
            this.login_bt = new System.Windows.Forms.Button();
            this.password_tb = new System.Windows.Forms.TextBox();
            this.password_lb = new System.Windows.Forms.Label();
            this.username_tb = new System.Windows.Forms.TextBox();
            this.username_lb = new System.Windows.Forms.Label();
            this.user_pb = new System.Windows.Forms.PictureBox();
            this.login_gb.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.user_pb)).BeginInit();
            this.SuspendLayout();
            // 
            // login_lb
            // 
            this.login_lb.BackColor = System.Drawing.SystemColors.Control;
            this.login_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.login_lb.Location = new System.Drawing.Point(12, 241);
            this.login_lb.Name = "login_lb";
            this.login_lb.Size = new System.Drawing.Size(458, 53);
            this.login_lb.TabIndex = 1;
            this.login_lb.Text = "Přihlášení";
            this.login_lb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // login_gb
            // 
            this.login_gb.Controls.Add(this.login_bt);
            this.login_gb.Controls.Add(this.password_tb);
            this.login_gb.Controls.Add(this.password_lb);
            this.login_gb.Controls.Add(this.username_tb);
            this.login_gb.Controls.Add(this.username_lb);
            this.login_gb.Location = new System.Drawing.Point(12, 297);
            this.login_gb.Name = "login_gb";
            this.login_gb.Size = new System.Drawing.Size(458, 260);
            this.login_gb.TabIndex = 2;
            this.login_gb.TabStop = false;
            // 
            // login_bt
            // 
            this.login_bt.BackColor = System.Drawing.SystemColors.ControlLight;
            this.login_bt.Cursor = System.Windows.Forms.Cursors.Hand;
            this.login_bt.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.login_bt.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.login_bt.Location = new System.Drawing.Point(6, 194);
            this.login_bt.Name = "login_bt";
            this.login_bt.Size = new System.Drawing.Size(446, 60);
            this.login_bt.TabIndex = 7;
            this.login_bt.Text = "Přihlásit";
            this.login_bt.UseVisualStyleBackColor = false;
            this.login_bt.Click += new System.EventHandler(this.login_bt_Click);
            // 
            // password_tb
            // 
            this.password_tb.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.password_tb.Location = new System.Drawing.Point(139, 120);
            this.password_tb.Name = "password_tb";
            this.password_tb.Size = new System.Drawing.Size(313, 38);
            this.password_tb.TabIndex = 6;
            this.password_tb.UseSystemPasswordChar = true;
            // 
            // password_lb
            // 
            this.password_lb.BackColor = System.Drawing.SystemColors.Control;
            this.password_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.password_lb.Location = new System.Drawing.Point(6, 120);
            this.password_lb.Name = "password_lb";
            this.password_lb.Size = new System.Drawing.Size(127, 38);
            this.password_lb.TabIndex = 5;
            this.password_lb.Text = "Heslo:";
            this.password_lb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // username_tb
            // 
            this.username_tb.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.username_tb.Location = new System.Drawing.Point(139, 47);
            this.username_tb.Name = "username_tb";
            this.username_tb.Size = new System.Drawing.Size(313, 38);
            this.username_tb.TabIndex = 4;
            // 
            // username_lb
            // 
            this.username_lb.BackColor = System.Drawing.SystemColors.Control;
            this.username_lb.Font = new System.Drawing.Font("Franklin Gothic Medium", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.username_lb.Location = new System.Drawing.Point(6, 47);
            this.username_lb.Name = "username_lb";
            this.username_lb.Size = new System.Drawing.Size(127, 38);
            this.username_lb.TabIndex = 3;
            this.username_lb.Text = "Jméno:";
            this.username_lb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // user_pb
            // 
            this.user_pb.BackColor = System.Drawing.SystemColors.ControlLight;
            this.user_pb.Image = global::HotelDatabase.Properties.Resources.user_img;
            this.user_pb.Location = new System.Drawing.Point(139, 25);
            this.user_pb.Name = "user_pb";
            this.user_pb.Size = new System.Drawing.Size(200, 200);
            this.user_pb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.user_pb.TabIndex = 0;
            this.user_pb.TabStop = false;
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(482, 568);
            this.Controls.Add(this.login_gb);
            this.Controls.Add(this.login_lb);
            this.Controls.Add(this.user_pb);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LoginForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.login_gb.ResumeLayout(false);
            this.login_gb.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.user_pb)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox user_pb;
        private System.Windows.Forms.Label login_lb;
        private System.Windows.Forms.GroupBox login_gb;
        private System.Windows.Forms.Button login_bt;
        private System.Windows.Forms.TextBox password_tb;
        private System.Windows.Forms.Label password_lb;
        private System.Windows.Forms.TextBox username_tb;
        private System.Windows.Forms.Label username_lb;
    }
}