﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace HotelDatabase
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void login_bt_Click(object sender, EventArgs e)
        {
            Connect conn = new Connect();
            DataTable table = new DataTable();
            MySqlDataAdapter adapter = new MySqlDataAdapter();
            MySqlCommand command = new MySqlCommand();
            String query = "SELECT * FROM `uživatelé` WHERE `Jména`=@usn AND `Hesla`=@pass";

            command.CommandText = query;
            command.Connection = conn.getConnection();

            command.Parameters.Add("@usn",MySqlDbType.VarChar).Value = username_tb.Text;
            command.Parameters.Add("@pass", MySqlDbType.VarChar).Value = password_tb.Text;

            adapter.SelectCommand = command;
            adapter.Fill(table);

            //Pravidla pro přihlášení
            if (table.Rows.Count > 0)
            {
                this.Hide();
                MainForm mform = new MainForm();
                mform.Show();
            }
            else
            {
                if (username_tb.Text.Trim().Equals(""))
                {
                    MessageBox.Show("Zadejte svoje jméno","Jméno je prázdné",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
                else if (password_tb.Text.Trim().Equals(""))
                {
                    MessageBox.Show("Zadejte svoje heslo", "Heslo je prázdné", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Toto jméno či heslo je špatně", "Přihlašovací údaje jsou špatné", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
